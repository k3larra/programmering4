package se.mah.k3lara.skaneAPI.view;

import java.util.ArrayList;
import java.util.Calendar;

import se.mah.k3lara.skaneAPI.control.Constants;
import se.mah.k3lara.skaneAPI.model.Journey;
import se.mah.k3lara.skaneAPI.model.Journeys;
import se.mah.k3lara.skaneAPI.model.Line;
import se.mah.k3lara.skaneAPI.model.Lines;
import se.mah.k3lara.skaneAPI.model.Station;
import se.mah.k3lara.skaneAPI.xmlparser.Parser;

public class TestClass {

	public static void main(String[] args) { 


		String searchURL = Constants.getURL("80002","80840",2); 
		System.out.println(searchURL);
		System.out.println("// Results when searching:");
		
		//hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation()+" - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY)+":"+journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in "+journey.realDepTime() +" motherfuckingminutes");
		} 
		

	}
}

private class Resor extends Thread {
	@Override
//mot c 2an
	public void run() {
		String searchURL = Constants.getURL("80002", "80600", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");

		}
	}
	//mot c 3an
	public void run1() {
		String searchURL = Constants.getURL("80002", "80110", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
	//mot c 5an
	public void run2() {
		String searchURL = Constants.getURL("80002", "80840", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
	//mot c 7an
	public void run3() {
		String searchURL = Constants.getURL("80002", "80580", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
	//mot c 8an
	public void run4() {
		String searchURL = Constants.getURL("80002", "80660", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
//från c 2an
	public void run5() {
		String searchURL = Constants.getURL("80002", "80005", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
	//från c 3an
	public void run6() {
		String searchURL = Constants.getURL("80002", "80300", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
	//från c 5an
	public void run7() {
		String searchURL = Constants.getURL("80002", "80004", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
	//från c 7an
	public void run8() {
		String searchURL = Constants.getURL("80002", "80338", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
	//från c 8an
	public void run9() {
		String searchURL = Constants.getURL("80002", "80040", 2);
		System.out.println(searchURL);
		System.out.println("// Results when searching:");

		// hämtar resor från skånetrafiken
		Journeys journeys = Parser.getJourneys(searchURL);
		for (Journey journey : journeys.getJourneys()) {
			System.out.print(journey.getStartStation() + " - ");
			System.out.print(journey.getEndStation());
			String time = journey.getDepDateTime().get(Calendar.HOUR_OF_DAY) + ":"
					+ journey.getDepDateTime().get(Calendar.MINUTE);
			System.out.println(" Departs in " + journey.realDepTime() + " motherfuckingminutes");
		}
	}
}